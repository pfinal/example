<?php

class Bar
{

}