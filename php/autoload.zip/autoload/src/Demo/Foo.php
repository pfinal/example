<?php

namespace Demo;

class Foo
{

}